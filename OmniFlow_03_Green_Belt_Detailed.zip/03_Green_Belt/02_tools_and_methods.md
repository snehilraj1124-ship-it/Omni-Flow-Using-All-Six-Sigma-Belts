# Green Belt — Tools and Methods

## Core Methods

### DMAIC
Used in the project to support structured improvement and evidence-based decision making.

### Descriptive Statistics
Used in the project to support structured improvement and evidence-based decision making.

### Pareto
Used in the project to support structured improvement and evidence-based decision making.

### Fishbone
Used in the project to support structured improvement and evidence-based decision making.

### Five Whys
Used in the project to support structured improvement and evidence-based decision making.

### Stratification
Used in the project to support structured improvement and evidence-based decision making.

### Driver Analysis
Used in the project to support structured improvement and evidence-based decision making.

### Hypothesis Register
Used in the project to support structured improvement and evidence-based decision making.

### Pilot Plan
Used in the project to support structured improvement and evidence-based decision making.

### Control Plan
Used in the project to support structured improvement and evidence-based decision making.

## Method Selection Principle

A tool should be selected because it answers a specific process question. More advanced statistical tools are not automatically better; the data type, measurement quality, assumptions and business question determine the appropriate method.
