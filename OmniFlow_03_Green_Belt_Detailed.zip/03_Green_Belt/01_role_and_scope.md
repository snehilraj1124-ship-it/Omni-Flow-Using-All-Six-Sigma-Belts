# Green Belt — Role and Scope

## Purpose

Green Belt is the project-execution layer of the OmniFlow case study.

The Green Belt connects process knowledge with quantitative analysis. The role is to take a defined problem, establish the baseline, analyze the available data, investigate potential causes, develop improvements and support control.

In the Measure phase, the Green Belt ensures that the data actually represents the CTQs. In Analyze, the Green Belt uses descriptive statistics, Pareto, stratification and driver analysis to identify patterns worth investigating. Fishbone and Five Whys organize possible causes, but the Green Belt should distinguish hypotheses from demonstrated causes.

In Improve, the Green Belt helps design Standard Work, Poka-Yoke, queue-management changes and pilot activities. In Control, the Green Belt helps define KPI ownership, monitoring frequency and reaction plans.

This project therefore uses the Green Belt layer to demonstrate the complete practical DMAIC workflow.

## Core Focus

DMAIC execution, quantitative analysis, root-cause investigation, improvement and pilot execution.

## Responsibilities

1. Execute an improvement project using DMAIC.
2. Build and validate the project baseline.
3. Analyze process data.
4. Investigate root-cause hypotheses.
5. Coordinate improvement actions.
6. Design and evaluate a pilot.
7. Support the Control phase.

## Scope Boundaries

The role should not be confused with every other belt. The belt hierarchy is collaborative. Higher-level roles generally provide more advanced analytical, leadership or deployment responsibility, while frontline participation remains important at every level.

## OmniFlow Context

The OmniFlow case concerns intake, validation, classification, routing, queueing, processing, quality checks, rework and closure.
