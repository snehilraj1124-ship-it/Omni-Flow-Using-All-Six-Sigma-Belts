# Green Belt — DMAIC Project Execution & Data-Driven Improvement

## 1. What is this belt?

Green Belt is the project-execution layer of the OmniFlow case study.

The Green Belt connects process knowledge with quantitative analysis. The role is to take a defined problem, establish the baseline, analyze the available data, investigate potential causes, develop improvements and support control.

In the Measure phase, the Green Belt ensures that the data actually represents the CTQs. In Analyze, the Green Belt uses descriptive statistics, Pareto, stratification and driver analysis to identify patterns worth investigating. Fishbone and Five Whys organize possible causes, but the Green Belt should distinguish hypotheses from demonstrated causes.

In Improve, the Green Belt helps design Standard Work, Poka-Yoke, queue-management changes and pilot activities. In Control, the Green Belt helps define KPI ownership, monitoring frequency and reaction plans.

This project therefore uses the Green Belt layer to demonstrate the complete practical DMAIC workflow.

---

## 2. Primary Focus

**DMAIC execution, quantitative analysis, root-cause investigation, improvement and pilot execution.**

---

## 3. Responsibilities

- Execute an improvement project using DMAIC.
- Build and validate the project baseline.
- Analyze process data.
- Investigate root-cause hypotheses.
- Coordinate improvement actions.
- Design and evaluate a pilot.
- Support the Control phase.

---

## 4. Tools & Methods

- DMAIC
- Descriptive Statistics
- Pareto
- Fishbone
- Five Whys
- Stratification
- Driver Analysis
- Hypothesis Register
- Pilot Plan
- Control Plan

---

## 5. Deliverables

- Project Charter
- Baseline analysis
- Pareto
- Root-cause analysis
- Driver analysis
- Improvement roadmap
- Pilot plan
- Control plan

---

## 6. Position in the Six Sigma System

```text
White Belt
   ↓
Yellow Belt
   ↓
Green Belt
   ↓
Black Belt
   ↓
Master Black Belt
```

This repository treats the belts as different levels of responsibility and methodology exposure. Actual certification requirements vary by certification provider.

---

## 7. OmniFlow Application

The belt is demonstrated through the OmniFlow fictional customer-case process. The project uses synthetic data and is intended as a portfolio/learning case study.

---

## 8. Important Distinction

A belt level describes a role or competency framework; it does not by itself prove certification. This repository demonstrates the methodology and associated project artifacts.
