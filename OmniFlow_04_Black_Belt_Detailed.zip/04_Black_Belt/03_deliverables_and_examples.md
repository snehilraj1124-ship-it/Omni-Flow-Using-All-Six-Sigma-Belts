# Black Belt — Deliverables and OmniFlow Examples

## Expected Deliverables

- Measurement strategy
- Variation analysis
- Capability framework
- Advanced analysis plan
- Risk analysis
- Control architecture
- Governance model

## Example OmniFlow Questions

- What problem is being addressed?
- Which customer requirement is affected?
- Which CTQ measures the requirement?
- What evidence supports the improvement hypothesis?
- What process change should be tested?
- How will the change be controlled?

## Evidence Standard

The project distinguishes between:
- observations
- hypotheses
- analysis
- validated conclusions
- improvement actions
- control requirements

Synthetic project outputs should not be represented as real-company performance.
