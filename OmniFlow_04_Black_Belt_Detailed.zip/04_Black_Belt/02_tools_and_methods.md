# Black Belt — Tools and Methods

## Core Methods

### Control Charts
Used in the project to support structured improvement and evidence-based decision making.

### Capability Analysis
Used in the project to support structured improvement and evidence-based decision making.

### Measurement System Analysis
Used in the project to support structured improvement and evidence-based decision making.

### Hypothesis Testing
Used in the project to support structured improvement and evidence-based decision making.

### Regression
Used in the project to support structured improvement and evidence-based decision making.

### ANOVA
Used in the project to support structured improvement and evidence-based decision making.

### Risk Analysis
Used in the project to support structured improvement and evidence-based decision making.

### Advanced Stratification
Used in the project to support structured improvement and evidence-based decision making.

### Statistical Process Control
Used in the project to support structured improvement and evidence-based decision making.

## Method Selection Principle

A tool should be selected because it answers a specific process question. More advanced statistical tools are not automatically better; the data type, measurement quality, assumptions and business question determine the appropriate method.
