# Black Belt — DMAIC Mapping

| DMAIC Phase | Black Belt Contribution |
|---|---|
| Define | Understand project purpose and role |
| Measure | Support appropriate measurement |
| Analyze | Apply the level-appropriate analysis |
| Improve | Support countermeasures and implementation |
| Control | Maintain standards and monitoring |

## Detailed Interpretation

The belt contributes across the DMAIC cycle, but the depth and responsibility vary by role. The important principle is collaboration rather than treating belts as isolated departments.
