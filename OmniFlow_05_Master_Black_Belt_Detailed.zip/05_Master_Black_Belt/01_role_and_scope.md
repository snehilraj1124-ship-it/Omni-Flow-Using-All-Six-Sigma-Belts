# Master Black Belt — Role and Scope

## Purpose

Master Black Belt is the organizational deployment layer in this project.

The Master Black Belt is not simply a 'higher Green Belt'. The focus changes from executing one project to building a system that enables many projects to be executed consistently.

For OmniFlow, this means defining how projects are selected, how belts are trained, how project quality is reviewed, how methods are standardized and how lessons from one process can be transferred to another.

A Master Black Belt perspective also protects methodological quality. For example, teams should not claim root cause merely because a Fishbone diagram contains a plausible cause. They should encourage appropriate measurement, evidence and validation.

The Master Black Belt layer therefore connects individual DMAIC projects with organizational learning, governance and continuous improvement culture.

## Core Focus

Enterprise deployment, coaching, standardization, project selection, governance and continuous-improvement capability.

## Responsibilities

1. Develop and standardize improvement methodology.
2. Coach Green Belts and Black Belts.
3. Support project selection and prioritization.
4. Create common templates and governance.
5. Review project quality and statistical rigor.
6. Replicate successful methods across processes.
7. Build long-term improvement capability.

## Scope Boundaries

The role should not be confused with every other belt. The belt hierarchy is collaborative. Higher-level roles generally provide more advanced analytical, leadership or deployment responsibility, while frontline participation remains important at every level.

## OmniFlow Context

The OmniFlow case concerns intake, validation, classification, routing, queueing, processing, quality checks, rework and closure.
