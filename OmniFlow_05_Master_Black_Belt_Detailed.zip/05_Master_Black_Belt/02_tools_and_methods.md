# Master Black Belt — Tools and Methods

## Core Methods

### Deployment Roadmap
Used in the project to support structured improvement and evidence-based decision making.

### Belt Training Architecture
Used in the project to support structured improvement and evidence-based decision making.

### Project Portfolio
Used in the project to support structured improvement and evidence-based decision making.

### Governance
Used in the project to support structured improvement and evidence-based decision making.

### Maturity Assessment
Used in the project to support structured improvement and evidence-based decision making.

### Coaching
Used in the project to support structured improvement and evidence-based decision making.

### Standard Templates
Used in the project to support structured improvement and evidence-based decision making.

### Replication Playbook
Used in the project to support structured improvement and evidence-based decision making.

### Continuous Improvement System
Used in the project to support structured improvement and evidence-based decision making.

## Method Selection Principle

A tool should be selected because it answers a specific process question. More advanced statistical tools are not automatically better; the data type, measurement quality, assumptions and business question determine the appropriate method.
