# White Belt — Tools and Methods

## Core Methods

### Lean wastes
Used in the project to support structured improvement and evidence-based decision making.

### Customer value
Used in the project to support structured improvement and evidence-based decision making.

### Basic process mapping
Used in the project to support structured improvement and evidence-based decision making.

### Visual management
Used in the project to support structured improvement and evidence-based decision making.

### Basic KPI awareness
Used in the project to support structured improvement and evidence-based decision making.

### PDCA awareness
Used in the project to support structured improvement and evidence-based decision making.

### 5S awareness
Used in the project to support structured improvement and evidence-based decision making.

## Method Selection Principle

A tool should be selected because it answers a specific process question. More advanced statistical tools are not automatically better; the data type, measurement quality, assumptions and business question determine the appropriate method.
