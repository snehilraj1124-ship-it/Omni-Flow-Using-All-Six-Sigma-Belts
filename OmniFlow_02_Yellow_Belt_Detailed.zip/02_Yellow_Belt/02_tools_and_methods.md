# Yellow Belt — Tools and Methods

## Core Methods

### SIPOC
Used in the project to support structured improvement and evidence-based decision making.

### VOC
Used in the project to support structured improvement and evidence-based decision making.

### CTQ
Used in the project to support structured improvement and evidence-based decision making.

### Process Map
Used in the project to support structured improvement and evidence-based decision making.

### Data Collection Plan
Used in the project to support structured improvement and evidence-based decision making.

### Pareto
Used in the project to support structured improvement and evidence-based decision making.

### Five Whys
Used in the project to support structured improvement and evidence-based decision making.

### Basic Fishbone
Used in the project to support structured improvement and evidence-based decision making.

## Method Selection Principle

A tool should be selected because it answers a specific process question. More advanced statistical tools are not automatically better; the data type, measurement quality, assumptions and business question determine the appropriate method.
