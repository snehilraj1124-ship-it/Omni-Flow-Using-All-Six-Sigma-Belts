# Yellow Belt — Role and Scope

## Purpose

Yellow Belt represents the transition from awareness to structured participation.

In OmniFlow, the Yellow Belt helps convert a vague problem such as 'customers are waiting too long' into a measurable problem. The team can ask what the customer means by quickly, which process stage consumes time, and which CTQ should represent that requirement.

Yellow Belt work is strongly connected to Define and Measure. SIPOC establishes the process boundary. VOC captures customer expectations. CTQ converts those expectations into measurable requirements. Operational definitions ensure that different people measure the same thing consistently.

Yellow Belts can also support basic root-cause analysis. They may participate in Pareto, Fishbone and Five Whys exercises. Their role is not to independently make advanced statistical conclusions; instead, they provide process knowledge and reliable observations to the project team.

## Core Focus

SIPOC, VOC, CTQ, process mapping, data collection and basic root-cause analysis.

## Responsibilities

1. Support a structured improvement team.
2. Map the high-level process.
3. Identify suppliers, inputs, process steps, outputs and customers.
4. Translate customer needs into measurable CTQs.
5. Support data collection and operational definitions.
6. Use basic problem-solving tools.

## Scope Boundaries

The role should not be confused with every other belt. The belt hierarchy is collaborative. Higher-level roles generally provide more advanced analytical, leadership or deployment responsibility, while frontline participation remains important at every level.

## OmniFlow Context

The OmniFlow case concerns intake, validation, classification, routing, queueing, processing, quality checks, rework and closure.
