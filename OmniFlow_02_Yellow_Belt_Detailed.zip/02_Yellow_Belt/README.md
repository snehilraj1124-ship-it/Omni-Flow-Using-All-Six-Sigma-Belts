# Yellow Belt — Structured Process Participation & Basic Problem Solving

## 1. What is this belt?

Yellow Belt represents the transition from awareness to structured participation.

In OmniFlow, the Yellow Belt helps convert a vague problem such as 'customers are waiting too long' into a measurable problem. The team can ask what the customer means by quickly, which process stage consumes time, and which CTQ should represent that requirement.

Yellow Belt work is strongly connected to Define and Measure. SIPOC establishes the process boundary. VOC captures customer expectations. CTQ converts those expectations into measurable requirements. Operational definitions ensure that different people measure the same thing consistently.

Yellow Belts can also support basic root-cause analysis. They may participate in Pareto, Fishbone and Five Whys exercises. Their role is not to independently make advanced statistical conclusions; instead, they provide process knowledge and reliable observations to the project team.

---

## 2. Primary Focus

**SIPOC, VOC, CTQ, process mapping, data collection and basic root-cause analysis.**

---

## 3. Responsibilities

- Support a structured improvement team.
- Map the high-level process.
- Identify suppliers, inputs, process steps, outputs and customers.
- Translate customer needs into measurable CTQs.
- Support data collection and operational definitions.
- Use basic problem-solving tools.

---

## 4. Tools & Methods

- SIPOC
- VOC
- CTQ
- Process Map
- Data Collection Plan
- Pareto
- Five Whys
- Basic Fishbone

---

## 5. Deliverables

- SIPOC
- VOC-to-CTQ mapping
- High-level process map
- Data collection plan
- Operational definitions
- Basic issue analysis

---

## 6. Position in the Six Sigma System

```text
White Belt
   ↓
Yellow Belt
   ↓
Green Belt
   ↓
Black Belt
   ↓
Master Black Belt
```

This repository treats the belts as different levels of responsibility and methodology exposure. Actual certification requirements vary by certification provider.

---

## 7. OmniFlow Application

The belt is demonstrated through the OmniFlow fictional customer-case process. The project uses synthetic data and is intended as a portfolio/learning case study.

---

## 8. Important Distinction

A belt level describes a role or competency framework; it does not by itself prove certification. This repository demonstrates the methodology and associated project artifacts.
