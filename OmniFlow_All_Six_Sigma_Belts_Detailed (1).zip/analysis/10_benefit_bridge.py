import json
m=json.load(open('../data/clean/summary_metrics.json'))
for k,v in m.items():
    if isinstance(v,(int,float)): print(k,round(v,4))
