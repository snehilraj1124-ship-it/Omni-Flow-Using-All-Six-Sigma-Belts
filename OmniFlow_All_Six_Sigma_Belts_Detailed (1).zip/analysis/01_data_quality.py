import pandas as pd
df=pd.read_csv('../data/clean/process_cases_clean.csv')
print('Rows:',len(df))
print('Missing values:')
print(df.isna().sum())
print('Duplicate Case IDs:',df.Case_ID.duplicated().sum())
print(df.describe(include='all'))
