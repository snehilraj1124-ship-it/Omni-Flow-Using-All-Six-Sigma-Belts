import pandas as pd
df=pd.read_csv('../data/clean/process_cases_clean.csv')
cols=['Queue_Wait_Min','Processing_Time_Min','Handoff_Count','Validation_Error','Input_Complete','Cycle_Time_Min']
print(df[cols].corr(numeric_only=True)['Cycle_Time_Min'].sort_values(ascending=False))
