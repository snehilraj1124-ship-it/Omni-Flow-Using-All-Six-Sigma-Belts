import pandas as pd
df=pd.read_csv('../data/clean/process_cases_clean.csv')
x=df.loc[df.Period=='Baseline','Cycle_Time_Min']
cl=x.mean(); s=x.std()
print('Center:',cl)
print('UCL:',cl+3*s)
print('LCL:',max(0,cl-3*s))
