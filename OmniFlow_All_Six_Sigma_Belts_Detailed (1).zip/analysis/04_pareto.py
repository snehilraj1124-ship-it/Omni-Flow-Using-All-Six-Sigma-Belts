import pandas as pd
themes=pd.Series({'Manual validation':34,'Incomplete inputs':27,'Queue imbalance':21,'Training variation':11,'System handoff delays':7}).sort_values(ascending=False)
print(themes)
print((themes.cumsum()/themes.sum()*100).round(1))
