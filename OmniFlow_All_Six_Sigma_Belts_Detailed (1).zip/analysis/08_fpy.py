import pandas as pd
df=pd.read_csv('../data/clean/process_cases_clean.csv')
print((df.groupby('Period')['First_Pass_Yield'].mean()*100).round(2))
