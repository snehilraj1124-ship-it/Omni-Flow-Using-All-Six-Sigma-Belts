import pandas as pd
df=pd.read_csv('../data/clean/process_cases_clean.csv')
for c in ['Channel','Region','Product','Shift','Agent_ID']:
    print('\n',c)
    print(df.groupby(c)['Cycle_Time_Min'].agg(['mean','median','count']).sort_values('mean',ascending=False).head(15))
