import pandas as pd
df=pd.read_csv('../data/clean/process_cases_clean.csv')
print(df.groupby('Period')['Customer_Satisfaction'].agg(['mean','median','std']))
