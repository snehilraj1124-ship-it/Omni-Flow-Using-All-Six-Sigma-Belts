import pandas as pd
df=pd.read_csv('../data/clean/process_cases_clean.csv')
cols=['Cycle_Time_Min','Queue_Wait_Min','Processing_Time_Min','Rework_Count','Backlog_Items','Customer_Satisfaction']
print(df.groupby('Period')[cols].agg(['mean','median','std']))
