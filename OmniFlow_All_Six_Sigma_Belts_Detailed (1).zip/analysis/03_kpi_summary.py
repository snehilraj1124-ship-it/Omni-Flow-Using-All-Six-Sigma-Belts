import pandas as pd
df=pd.read_csv('../data/clean/process_cases_clean.csv')
summary=df.groupby('Period').agg(
    Cycle_Time=('Cycle_Time_Min','mean'),
    Defect_Rate=('Defect','mean'),
    FPY=('First_Pass_Yield','mean'),
    Rework=('Rework_Count','mean'),
    Backlog=('Backlog_Items','mean'),
    Satisfaction=('Customer_Satisfaction','mean')
)
print(summary)
