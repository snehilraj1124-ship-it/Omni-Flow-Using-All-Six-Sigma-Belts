# Analyze — Hypothesis Register

H1: incomplete input is associated with longer cycle time.
H2: handoffs are associated with longer cycle time.
H3: validation errors are associated with rework.
H4: queue wait is a major contributor to cycle time.
H5: standard work and early validation can reduce defects.

These are hypotheses requiring evidence; they are not automatically causal conclusions.
