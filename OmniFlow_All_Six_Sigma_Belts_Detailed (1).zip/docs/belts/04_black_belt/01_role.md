# Black Belt — Role

Black Belt provides advanced project leadership and statistical thinking.

## Focus
- Variation
- Statistical inference
- Capability
- Control
- Risk
- Cross-functional leadership
