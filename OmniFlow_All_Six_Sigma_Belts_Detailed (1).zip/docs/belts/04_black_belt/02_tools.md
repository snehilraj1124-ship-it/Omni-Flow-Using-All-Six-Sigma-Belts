# Black Belt — Tools

Potential tools:
- Control charts
- Capability analysis
- Hypothesis testing
- Regression
- ANOVA
- Measurement-system analysis
- Risk analysis
- Advanced process analysis

OmniFlow provides frameworks for these methods and executable starter scripts.
