# Yellow Belt — Tools

Tools demonstrated in OmniFlow:
- SIPOC
- Process map
- VOC
- CTQ tree
- Data collection plan
- Operational definitions
- Basic Pareto
- Basic Five Whys
