# Yellow Belt — Role

Yellow Belt supports structured team improvement.

## Focus
- Process mapping
- SIPOC
- VOC
- CTQ
- Data collection
- Basic RCA
