# Yellow Belt — Deliverables

OmniFlow deliverables:
- SIPOC
- VOC-to-CTQ mapping
- High-level process map
- Data collection plan
- Operational definitions
- Basic issue identification
