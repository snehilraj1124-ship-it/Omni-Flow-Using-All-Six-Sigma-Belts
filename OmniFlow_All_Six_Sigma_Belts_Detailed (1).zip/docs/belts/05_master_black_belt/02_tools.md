# Master Black Belt — Tools

Typical deployment mechanisms:
- Belt training architecture
- Project selection
- Governance
- Standard templates
- Maturity assessments
- Coaching
- Replication playbooks
- Portfolio reviews
