# Master Black Belt — Role

Master Black Belt focuses on improvement-system deployment.

## Focus
- Methodology
- Coaching
- Governance
- Replication
- Standardization
- Improvement portfolio
