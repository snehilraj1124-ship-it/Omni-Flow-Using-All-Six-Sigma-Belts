# White Belt — Tools and Concepts

Core concepts:
- 8 wastes
- Customer value
- Process thinking
- Basic problem identification
- Visual management
- Standard work awareness

The emphasis is understanding rather than advanced statistical analysis.
