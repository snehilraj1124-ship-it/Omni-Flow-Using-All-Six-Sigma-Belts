# White Belt — Role

White Belt is the foundational awareness level.

## Focus
- Improvement vocabulary
- Customer value
- Waste
- Defects
- Variation
- Team participation

## OmniFlow application
A White Belt participant should understand why cycle time, defects, rework and backlog matter and recognize opportunities for improvement.
