# Green Belt — Role

Green Belt is the project-execution layer.

## Focus
- DMAIC
- Quantitative analysis
- Root-cause investigation
- Improvement design
- Pilot

The Green Belt connects process knowledge with structured data analysis.
