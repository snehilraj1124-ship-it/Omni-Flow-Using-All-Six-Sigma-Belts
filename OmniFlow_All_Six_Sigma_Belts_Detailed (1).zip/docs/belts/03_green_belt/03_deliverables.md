# Green Belt — Deliverables

- Project charter
- Baseline analysis
- Pareto
- Root-cause analysis
- Improvement roadmap
- Pilot
- Control plan
- KPI tracking
