# Green Belt — Tools

OmniFlow Green Belt tools:
- Descriptive statistics
- Pareto
- Fishbone
- Five Whys
- Stratification
- Driver analysis
- Hypothesis register
- Pilot plan
- Control plan
