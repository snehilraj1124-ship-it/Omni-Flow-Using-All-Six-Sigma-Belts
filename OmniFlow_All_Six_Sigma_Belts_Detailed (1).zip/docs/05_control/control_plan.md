# Control — Control Plan

Daily:
- cycle time
- defect rate
- backlog

Weekly:
- rework
- action review

Monthly:
- audit
- control-plan review

Quarterly:
- maturity review
- replication assessment
