# Stakeholder Map

Executive Sponsor: strategic support.
Champion: portfolio alignment and barriers.
Process Owner: end-to-end process performance.
Quality Lead: defect prevention.
Green Belt: project execution.
Black Belt: advanced analysis.
Master Black Belt: methodology and deployment.
Frontline Team: daily process execution.
