# Project Summary

OmniFlow is a fictional customer case-processing operation used to demonstrate a complete Lean Six Sigma transformation.

Scope: intake through closure.

Primary CTQs: cycle time, defect rate, FPY, rework, backlog and customer satisfaction.
