# Business Case

Potential value categories:
- reduced waiting
- reduced rework
- improved throughput
- fewer defects
- improved customer experience
- clearer ownership

No real monetary savings are claimed because the data is synthetic.
