# VOC, CTQ and SIPOC

VOC captures customer needs in customer language.

CTQ converts those needs into measurable requirements.

SIPOC defines the high-level process boundary by identifying Suppliers, Inputs, Process, Outputs and Customers.

Example:
VOC = "Resolve quickly"
CTQ = Cycle Time
Metric = Minutes per case
