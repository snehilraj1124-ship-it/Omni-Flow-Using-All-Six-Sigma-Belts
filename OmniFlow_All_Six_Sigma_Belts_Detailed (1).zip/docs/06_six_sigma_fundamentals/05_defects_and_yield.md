# Defects and Yield

Defect measures an undesired quality outcome.

Yield measures successful output.

First Pass Yield is particularly useful when rework is costly because it focuses on getting the work right without correction.

OmniFlow uses:
Defect = 1 when a case contains a defect.
FPY = 1 only when there is no defect and no rework.
