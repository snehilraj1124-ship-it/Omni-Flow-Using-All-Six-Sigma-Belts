# Poka-Yoke and Standard Work

Poka-Yoke prevents or detects errors at the source.

Standard Work defines the current best-known sequence, timing, quality requirements and control points.

Together they reduce avoidable variation and make process expectations visible.
