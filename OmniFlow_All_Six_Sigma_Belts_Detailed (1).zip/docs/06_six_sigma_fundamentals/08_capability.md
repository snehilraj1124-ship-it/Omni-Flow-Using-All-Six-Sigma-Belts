# Capability

Capability compares process performance with specification requirements.

Common indices:
- Cp
- Cpk
- Pp
- Ppk

Capability interpretation requires appropriate data, stable behavior and valid specification limits.
