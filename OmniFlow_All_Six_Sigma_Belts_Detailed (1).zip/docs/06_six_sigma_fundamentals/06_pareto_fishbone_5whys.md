# Pareto, Fishbone and Five Whys

## Pareto
Prioritizes categories by frequency or impact.

## Fishbone
Organizes possible causes into categories.

## Five Whys
Explores a causal chain by repeatedly asking why.

These tools generate and structure hypotheses. They do not automatically prove causation.
