# DMAIC Deep Dive

## Define
Create a clear problem statement, project charter, scope, customer requirements and business case.

## Measure
Create operational definitions, validate data and establish the baseline.

## Analyze
Investigate variation, patterns, relationships and root-cause hypotheses.

## Improve
Develop, test and validate countermeasures.

## Control
Standardize the improved process, monitor CTQs and define reaction plans.

DMAIC is iterative in practice: learning in later phases may cause earlier assumptions to be refined.
