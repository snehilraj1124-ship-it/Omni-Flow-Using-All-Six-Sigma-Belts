# Lean vs Six Sigma

## Lean
Lean focuses on customer value, flow and waste reduction.

## Six Sigma
Six Sigma focuses on defects, variation, measurement and data-driven improvement.

## Combined approach
Lean can expose where the process is slow or wasteful. Six Sigma can help quantify variation and investigate drivers.

## OmniFlow examples
Lean opportunities: queue waiting, unnecessary handoffs, duplicate work.
Six Sigma opportunities: defect rate, variation, FPY and statistical control.
