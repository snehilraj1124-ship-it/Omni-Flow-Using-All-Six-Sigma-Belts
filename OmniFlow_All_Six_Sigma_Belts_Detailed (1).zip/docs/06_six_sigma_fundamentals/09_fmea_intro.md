# FMEA Introduction

Failure Mode and Effects Analysis is a structured risk-analysis method.

Typical fields:
- Process step
- Failure mode
- Effect
- Cause
- Existing control
- Severity
- Occurrence
- Detection
- Risk priority approach

FMEA is useful before or during improvement design.
