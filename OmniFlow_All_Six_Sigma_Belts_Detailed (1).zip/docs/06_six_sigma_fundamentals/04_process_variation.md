# Process Variation

Variation is the difference between individual process observations.

Two broad categories are useful:
- Common-cause variation: inherent to the current system.
- Special-cause variation: attributable to a specific unusual event or condition.

Control charts are commonly used to distinguish stable process behavior from potential special causes.
