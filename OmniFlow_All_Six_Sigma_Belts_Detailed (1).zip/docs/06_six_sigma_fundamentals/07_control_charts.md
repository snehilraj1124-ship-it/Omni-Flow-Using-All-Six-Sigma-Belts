# Control Charts

A control chart displays process observations over time with a center line and statistically derived control limits.

Purpose:
- detect unusual process behavior
- separate common and special causes
- support stable-process monitoring

Control limits are different from specification limits.
