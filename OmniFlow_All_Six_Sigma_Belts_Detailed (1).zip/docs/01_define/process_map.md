# Define — Process Map

1. Intake
2. Validate
3. Classify
4. Route
5. Queue
6. Process
7. Quality Check
8. Rework if required
9. Close

Potential waste points include waiting, handoffs, duplicate checking and avoidable rework.
