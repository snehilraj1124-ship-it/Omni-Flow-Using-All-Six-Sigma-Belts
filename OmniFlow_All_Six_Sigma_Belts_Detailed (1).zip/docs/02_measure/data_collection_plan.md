# Measure — Data Collection Plan

Unit of analysis: one case.

Required fields cover:
- identity
- process segment
- input quality
- validation
- handoffs
- time
- defects
- rework
- backlog
- satisfaction
- first-pass quality
