SELECT Channel, AVG(Cycle_Time_Min) AS Avg_Cycle_Time
FROM process_cases
GROUP BY Channel
ORDER BY Avg_Cycle_Time DESC;

SELECT Agent_ID, AVG(Cycle_Time_Min) AS Avg_Cycle_Time
FROM process_cases
GROUP BY Agent_ID
ORDER BY Avg_Cycle_Time DESC;
