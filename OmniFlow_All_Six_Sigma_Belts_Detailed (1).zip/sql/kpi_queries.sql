SELECT Period, AVG(Cycle_Time_Min) AS Avg_Cycle_Time
FROM process_cases
GROUP BY Period;

SELECT Period, AVG(Defect)*100 AS Defect_Rate_Pct
FROM process_cases
GROUP BY Period;

SELECT Period, AVG(First_Pass_Yield)*100 AS FPY_Pct
FROM process_cases
GROUP BY Period;
