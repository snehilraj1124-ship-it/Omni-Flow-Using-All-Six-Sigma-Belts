SELECT Defect_Type, COUNT(*) AS Defect_Count
FROM defect_log
GROUP BY Defect_Type
ORDER BY Defect_Count DESC;
